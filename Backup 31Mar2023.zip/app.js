﻿$("#gotop").click(function () {
    $("html, body").animate({
        scrollTop: "0px"
    }, 800);
});

var objInterval = undefined;
const _baseUrl = {
    Prod: 'http://nebula/APIService/api/',
    Test: 'http://localhost:61179/api/'
}
const config = {
    PollingInterval: 15,
    Environment: { BaseUrl: _baseUrl.Prod } // Change the Environment here ( Prod or Test)
};
document.addEventListener('DOMContentLoaded', () => {
    Main();
    objInterval = setInterval(Main, config.PollingInterval * 1000);
});
function Main() {
    processData().then((data) => {
        BuildProgressTracker(data);
        BuildTable(data);
        ApplySyntaxColor();
        AddCopyEvents();
    });
}

async function processData() {
    const url = config.Environment.BaseUrl + '/finpulsetracker'
    return new Promise((resolve, reject) => {
        $.getJSON(url, {}, function (data, textStatus, jqXHR) {
            var items = data;
            resolve(data);
        });
    });

}

function BuildProgressTracker(items) {
    var $Container = $('#Container');
    $Container.html('');

    items.forEach((item) => {
        var clas = item.Status.toLowerCase();
        var ProgressTracker2 =
            `
        
         <span class="${clas} icon"  id="icon">
         <a href="#${item.SequenceNo}"class="text" >${item.SequenceNo}
         <h5 >${item.Title}</h5>
         </a>
         
         </span>
         <span>    </span>
         
        `
        $Container.append($(ProgressTracker2))
    });


}

function BuildTable(items) {

    var $Container = $('#divContainer');
    $Container.html('');



    items.forEach((item) => {

        var query = item.QueryText;
        var user = item.InProgressByUser;
        var clas = item.Status.toLowerCase();
        var hdnuser = document.getElementById('hdnUser').value;
        query = query.replace("'inprogress'", "'inprogress' , InProgressByUser ='" + hdnuser + "' ");


        var template =
            `<div class="divRow ">
    <div class="divcopy  ">
    <h2 id="${item.SequenceNo}"> ${item.SequenceNo}. ${item.Title} <span style='position: absolute;color:red;margin-left: 100px;right: 150px;' > ${user} </span> </h2>
    <button class="btnCopy" type='button'>Copy SQL</button>
    </div> 
<pre class="${clas}"><code class="language-sql ${clas}">     
${query}

</code></pre>

</div><br/>`
        $Container.append($(template));
    });
}




function ApplySyntaxColor() {

    document.querySelectorAll('pre code').forEach((el) => {
        hljs.highlightElement(el);
    });


}

function AddCopyEvents() {


    $('.btnCopy').click(function (el) {


        var copyText = this.parentElement.parentElement.getElementsByTagName('code')[0].innerText

        var textArea = document.createElement("textarea");
        textArea.value = copyText;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand("Copy");
        textArea.remove();

        this.innerText = '  🗸 Copied'
        this.style.color = 'white';
        this.style.backgroundColor = 'green';
        setTimeout(() => {
            this.innerText = 'Copy SQL'
            this.style.color = 'darkslategray';
            this.style.backgroundColor = '#f2f2f2';
        }, 1200);
    });
}


